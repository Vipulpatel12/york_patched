TOKEN_URL = "https://app.patched.codes/signin"
DEFAULT_PATCH_URL = "https://patchwork.patched.codes/v1"
PROMPT_TEMPLATE_FILE_KEY = "prompt_template_file"
